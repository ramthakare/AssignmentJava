package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Document;
import com.example.demo.layer2.Loan;
import com.example.demo.layer3.CustomerReposioryImpl;
import com.example.demo.layer3.DocumentRepositoryImpl;

@SpringBootTest
public class DocumentTest 
{
 @Autowired
 DocumentRepositoryImpl DocRepo;
 

	@Test
	void insertDocumentTest()
	{
		
		Document document=new Document();
	
		document.setPanCard("ghhjgjgh");
		document.setVoterId("hjghgjkhj");
		document.setSalarySlip("kjkhjh");
		document.setLoa(2);
		document.setNocFromBuilder("jhnjhjhki");
		document.setAgreementToSale("jkhkhki");
	
		DocRepo.insertDocument(document);
		
		
	}
	

 
}
