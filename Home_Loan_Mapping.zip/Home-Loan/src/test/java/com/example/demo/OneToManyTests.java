package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Document;
import com.example.demo.layer3.CustomerReposioryImpl;
import com.example.demo.layer3.DocumentRepositoryImpl;

public class OneToManyTests 
{
	@Autowired
	CustomerReposioryImpl cusRepo;
	
	 @Autowired
	 DocumentRepositoryImpl DocRepo;
	 
	@Test
	void insertDocument()
	{
	 Customer customer =cusRepo.selectCustomer(33);
		Document doc=new Document();
		{
			doc.setPanCard("Ram1234cu");
			doc.setVoterId("hjkkfj68574");
			doc.setLoa(1627384);
			doc.setNocFromBuilder("hjwdjhjkhjkhjkh");
			doc.setSalarySlip("yes");
			doc.setAgreementToSale("Yes");
			doc.setCustomer(customer);
			
			DocRepo.insertDocument(doc);
			
		}
	}
//	@Test
//	void manyRequestBidsToOneFarmer() {
//
//	Farmer farmerObj=farmerRepo.fetchFarmerDetailsById(11);
//
//	RequestBid requestBidObj=new RequestBid();
//	requestBidObj.setCropName("Rice");
//	requestBidObj.setQuantityOfCrop(50.2);
//	requestBidObj.setPhOfSoil(7.2);
//	requestBidObj.setFertilizerType("Organic");
//	requestBidObj.setFarmerObj3(farmerObj);
//	requestBidRepo.insertRequestBid(requestBidObj);
//
//	RequestBid requestBidObj2=new RequestBid();
//	requestBidObj2.setCropName("Jwar");
//	requestBidObj2.setQuantityOfCrop(50.2);
//	requestBidObj2.setPhOfSoil(7.2);
//	requestBidObj2.setFertilizerType("Organic");
//	requestBidObj2.setFarmerObj3(farmerObj);
//	requestBidRepo.insertRequestBid(requestBidObj2);


	}




