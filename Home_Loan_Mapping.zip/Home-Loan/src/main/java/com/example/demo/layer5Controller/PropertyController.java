package com.example.demo.layer5Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Property;
import com.example.demo.layer3.PropertyRepositoryImpl;

@RestController
@RequestMapping("/property")
public class PropertyController {

	@Autowired
	PropertyRepositoryImpl proRepo;
	
	@GetMapping("/getProperty/{x}")//localhost:8080/property/getProperty/
	public Property getProperty(@PathVariable int x)
	{
		Property property = null;
		property=proRepo.selectProperty(x);
		
		System.out.println("controller : property : "+property.getPropertyId());
		return property;
	}


	@GetMapping("/getAll")
	public List<Property> getProperties()
	{
	List<Property> propertyList;
	propertyList=proRepo.selectPropertys();
	return propertyList;
	}
	
	@PostMapping("/Add")
	public void addProperty(@RequestBody Property property)
	{
		proRepo.insertProperty(property);
	}
	
	@PutMapping("/update")//localhost:8080/property/update
	public void updateProperty(@RequestBody Property property)
	{
		proRepo.updateProperty(property);
	}
		@DeleteMapping("/delete/{propertyId}")//http://localhost:8080/cust/delete/45
	 public String deleteProperty(@PathVariable("propertyId") int propertyId)
	 {
		proRepo.deleteProperty(propertyId);
	 return "delete successfully";
 }
	
}
