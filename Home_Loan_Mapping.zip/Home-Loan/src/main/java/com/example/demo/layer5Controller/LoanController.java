package com.example.demo.layer5Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Loan;
import com.example.demo.layer2.Property;
import com.example.demo.layer3.LoanRepositoryImpl;

@RestController
@RequestMapping("/loan")
public class LoanController {

	@Autowired
	LoanRepositoryImpl loanRepo;
	
	@GetMapping("/getloan/{loanId}")//localhost:8080/loan/getloan
	public Loan getLoan(@PathVariable("loanId") int x)
	{
		Loan loan = null;
		loan=loanRepo.selectLoan(x);
		
		System.out.println("controller : loan : "+loan.getLoanId());
		return loan;
	}
	@GetMapping("/getAll")//localhost:8080/loan/getAll
	public List<Loan> getloans()
	{
		System.out.println("getAll");
		List<Loan> loanList;
		loanList=loanRepo.selectLoans();
		return loanList;
	}
	
	@PostMapping("/Add")//localhost:8080/loan/Add
	public void addLoan(@RequestBody Loan loan)
	{
		loanRepo.insertLoan(loan);
	}
	
	
	@PostMapping("/update")//http://localhost:8080/loan/update
	public void updateLoan(@RequestBody Loan loan)
	{
		loanRepo.updateLoan(loan);
	}
	
		@DeleteMapping("/delete/{loanId}")//http://localhost:8080/cust/delete/45
	 public String deleteLoan(@PathVariable("loanId") int loanId)
	 {
			loanRepo.deleteLoan(loanId);
	 return "delete successfully";
 }
}
