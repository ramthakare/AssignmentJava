package com.example.demo.layer5Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Customer;

import com.example.demo.layer3.CustomerReposioryImpl;

@RestController
@RequestMapping("/cust")
public class CustomerController {

	@Autowired
	CustomerReposioryImpl cusRepo;

	
	@GetMapping("/getCust/{x}")//localhost:8080/cust/getCust
	public Customer getCust(@PathVariable int x)
	{
		Customer cust = null;
		cust=cusRepo.selectCustomer(x);
		
		System.out.println("controller : cust : "+cust.getCust_Id());
		return cust;
	}


	@GetMapping("/getAll")
	public List<Customer> getCustomers()
	{
	List<Customer> customerList;
	customerList=cusRepo.selectCustomers();
	return customerList;
	}
	
	@PostMapping("/Add")
	public void addCustomers(@RequestBody Customer customer)
	{
		cusRepo.insertCustomer(customer);
	}
	
	@PutMapping("/update")//http://localhost:8080/cust/update
	public void updateCustomer(@RequestBody Customer customer)
	{
		cusRepo.updateCustomer(customer);
	}
	
	@DeleteMapping("/delete/{cust_id}")//http://localhost:8080/cust/delete/45
	 public String deleteCustomer(@PathVariable("cust_id") int cust_id)
	 {
		cusRepo.deleteCustomer(cust_id);
	 return "delete successfully";
	 }
	
}
