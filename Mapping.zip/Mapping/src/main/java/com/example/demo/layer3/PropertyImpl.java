package com.example.demo.layer3;

public class PropertyImpl implements PropertyRepo
{

}
