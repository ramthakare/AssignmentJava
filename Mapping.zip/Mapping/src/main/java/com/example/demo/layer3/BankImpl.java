package com.example.demo.layer3;

public class BankImpl implements BankRepo {

}
