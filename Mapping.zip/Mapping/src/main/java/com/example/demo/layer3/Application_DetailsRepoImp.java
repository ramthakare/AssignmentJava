package com.example.demo.layer3;

public class Application_DetailsRepoImp implements Application_DetailsRepo 
{

}
