package com.example.demo.layer3;

public class DocumentImpl implements DocumentRepo 
{

}
