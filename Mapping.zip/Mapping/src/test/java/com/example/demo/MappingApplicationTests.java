package com.example.demo;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.OneToOne;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Application_Details;
import com.example.demo.layer2.Bank;
import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Document;

import com.example.demo.layer2.Loan;
import com.example.demo.layer2.Property;
import com.example.demo.layer2.Tracker;






@SpringBootTest
class MappingApplicationTests {

	
	@Test
	public void insertProperty() 
	{
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		System.out.println("Transaction started....");
		
		Property per = new Property();
		System.out.println("POJO created...");
		
		per.setPropertyId(80);
		per.setPropertyLoc("Pune");
		per.setPropertyName("2 Bhkflat");
		per.setEstimatedAmt(1434.0f);
		per.setTypeOfEmp("permant");
		per.setRetAge(65);
		per.setOrgType("Software Developer");
		per.setEmployerName("Ram");
		per.setIncome("35000");
		
		
		System.out.println("POJO filled up..");
		
		entityManager.persist(per);
		System.out.println("Persited...");
		
         transaction.commit();
     System.out.println("Committed...");
}

	@Test
	public void insertCustomer()  
	{
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		System.out.println("Transaction started....");
		
		Customer Cus = new Customer();
		System.out.println("POJO created...");
	     
		Cus.setFirstName("ram_neova");
		Cus.setMiddleName("gajanan");
		Cus.setLastName("Thakare");
		Cus.setEmail("kru4797@gmail.com");
		Cus.setPassword("ram@827761");
		Cus.setPhoneNo(880512891);
		Cus.setDob(LocalDate.of(2022, 11, 25));
		Cus.setNationality("Indian");
		Cus.setAdhaarNo(123454232);
		Cus.setPanCard("Ramkr223t8");
		
		
		
		System.out.println("POJO filled up..");
		
		entityManager.persist(Cus);
		System.out.println("Persited...");
		
      transaction.commit();
      System.out.println("Committed...");
}
	@Test
	void assignExistingPropertyToExistingCustomer()
	{
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
	
		
				Customer customer	  = entityManager.find(Customer.class, 2);
				Property property = entityManager.find(Property.class, 30);
				
				customer.setProperty(property);// are we setting the FK?
				property.setCustomer(customer); // are we setting the FK?
				
				entityManager.merge(customer);
				entityManager.merge(property);
				
		transaction.commit();		
		
	}
	
	@Test
	public void insertApplication()  
	{
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		System.out.println("Transaction started....");
		
		Application_Details application = new Application_Details();
		System.out.println("POJO created...");
	     
		application.setComments("Fail,Not Clear All Documents");
		application.setStatus("fail");
		application.setExpected_Amount(25000);
		application.setTenure(2);
		
		
		
		
		System.out.println("POJO filled up..");
		
		entityManager.persist(application);
		System.out.println("Persited...");
		
      transaction.commit();
      System.out.println("Committed...");
}
	
	@Test
	void assignExistingApplicationToExistingCustomer()
	{
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
	
		
				Customer customer	  = entityManager.find(Customer.class, 2);
				Application_Details application = entityManager.find(Application_Details.class, 5);
				
				customer.setApplication_details(application);// are we setting the FK?
				application.setCustomer(customer); // are we setting the FK?
				
				entityManager.merge(customer);
				entityManager.merge(application);
				
		transaction.commit();		
		
	}
	
	@Test
	public void insertbankOperation() 
	{
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		System.out.println("Transaction started....");
		
		Bank ban = new Bank();
		System.out.println("POJO created...");
		
		
		ban.setBankName("Hdfc");
		ban.setAccountNo(223453);
		ban.setIfscCode("hdjj8723k");
		
		System.out.println("POJO filled up..");
		
		entityManager.persist(ban);
		System.out.println("Persited...");
		
         transaction.commit();
     System.out.println("Committed...");
}
	
	
	   @Test
	   void assignExistingBankToExistingCustomer()
	   
	   {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
	
		
				Customer customer	  = entityManager.find(Customer.class, 2);
				Bank bank = entityManager.find(Bank.class, 8);
				
				customer.setBank(bank);// are we setting the FK?
				bank.setCustomer(customer); // are we setting the FK?
				
				entityManager.merge(customer);
				entityManager.merge(bank);
				
		transaction.commit();		
		
	}
	
	
	
	   @Test
	public void insertloan() 
	{
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		System.out.println("Transaction started....");
		
		Loan loan= new Loan();
		System.out.println("POJO created...");
		
		loan.setLoanId(4);
		loan.setMaxLoanGrant(2400.0f);
		loan.setTenure(3);
		loan.setLoanAmount(242000.0f);
		loan.setRoi(3.5);
		loan.setEmi(250.0f);
		
		
		System.out.println("POJO filled up..");
		
		entityManager.persist(loan);
		System.out.println("Persited...");
		
         transaction.commit();
     System.out.println("Committed...");
}
	   @Test
	public void insertDocument() 
	{
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		System.out.println("Transaction started....");
		
		Document d = new Document();
		
		System.out.println("POJO created...");
		
		d.setPanCard("PQY");
		d.setAgreementToSale("PQY");
		
		d.setLoa(250);
		
		
		d.setVoterId("PQY");
		
		System.out.println("POJO filled up..");
		
		entityManager.persist(d);
		System.out.println("Persited...");
		
         transaction.commit();
     System.out.println("Committed...");
}
	   
	   @Test
		public void insertAdmin() 
		{
			EntityManagerFactory entityManagerFactory = 
					Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
			
			System.out.println("Entity Manager Factory : "+entityManagerFactory);
			
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			//ctrl+shift+M
			
			System.out.println("Entity Manager : "+entityManager);
			
			EntityTransaction transaction = entityManager.getTransaction();
			transaction.begin();
			System.out.println("Transaction started....");
			
			Admin admin= new Admin();
			System.out.println("POJO created...");
			
			admin.setUsername("Ramth");
			admin.setPassword("1234@");
			
			System.out.println("POJO filled up..");
			
			entityManager.persist(admin);
			System.out.println("Persited...");
			
	         transaction.commit();
	     System.out.println("Committed...");
	}
	

}
