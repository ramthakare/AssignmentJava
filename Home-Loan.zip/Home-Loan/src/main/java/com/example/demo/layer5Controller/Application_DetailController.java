package com.example.demo.layer5Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Application_Details;
import com.example.demo.layer3.Application_DetailsRepoImp;


@RestController
@RequestMapping("/application")
public class Application_DetailController {

	@Autowired
	Application_DetailsRepoImp AppRepo;
	
	@GetMapping("/getapplication/{application_No}")//localhost:8080/application/getapplication/34
	public Application_Details getApplication(@PathVariable("application_No") int x)
	{
		Application_Details application = null;
		application=AppRepo.selectApplication_Details(x);
		
		System.out.println("controller : application : "+application.getApplication_No());
		return application;
	}
	@RequestMapping("/getAll")//localhost:8080/application/getAll
	public List<Application_Details> getApplication_Details()
	{
		System.out.println("getAll");
		List<Application_Details> applicationList;
		applicationList=AppRepo.selectApplication_Details();
		return applicationList;
	}
	
	@PostMapping("/Add")
	public void addApplication_Details(@RequestBody Application_Details application_Details)
	{
		AppRepo.insertApplication_Details(application_Details);
	}
	
	@PutMapping("/update")//http://localhost:8080/application/update
	public void updateApplication_Details(@RequestBody Application_Details application_Details)
	{
		AppRepo.updateApplication_Details(application_Details);
	}
	
	@DeleteMapping("/delete/{application_No}")//http://localhost:8080/application/delete/45
	 public String deleteApplication_Details(@PathVariable("application_No") int application_No)
	 {
		AppRepo.deleteApplication_Details(application_No);
	 return "delete successfully";
	 }
	
}
