package com.example.demo.layer5Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Document;
import com.example.demo.layer3.DocumentRepositoryImpl;



@RestController
@RequestMapping("/document")
public class DocumentController {

	
	@Autowired
	DocumentRepositoryImpl docRepo;
	
	@GetMapping("/getdocument/{docId}")//localhost:8080/document/getdocument
	public Document getDocument(@PathVariable("docId") int x)
	{
	    Document document=null;
	    document=docRepo.selectDocument(x);
		
		System.out.println("controller : document : "+document.getDocId());
		return document;
	}
}
